# BongBong Screen Filter

App de Android que aplica a TODA la pantalla (dentro de cualquier juego o app) el color grade de tu
shader BongBongColory: tinte azul, saturación, brillo y contraste. Usa una matriz de color de
SurfaceFlinger, así que no consume GPU ni añade retraso.

## Qué incluye y qué no
- Incluye: tinte (tono y fuerza), ganancia base, saturación, brillo, contraste. Es el mismo cálculo
  que `colorGrade()` del .fsh (verificado numéricamente, error menor a 0,000001).
- No incluye: ACES, bloom, nitidez (CAS), HDR local ni grano. Son operaciones por pixel que una
  matriz de color no puede hacer, y una app normal no puede filtrar otras apps con shaders.
- Si tus juegos son de PSP, copia los tres archivos del shader a la carpeta `shaders` de PPSSPP y se
  aplican completos, sin esta app.

## Compilar el APK con GitHub Actions
1. Crea un repositorio nuevo en GitHub (privado o público).
2. Sube todo el contenido de esta carpeta, incluida la carpeta oculta `.github`.
   Si la web no deja subir `.github`, crea el archivo a mano: Add file > Create new file, escribe
   `.github/workflows/build.yml` y pega el contenido del `build.yml` de este proyecto.
3. Ve a la pestaña Actions, elige "Build APK" y pulsa Run workflow (también corre solo al subir).
4. Cuando termine, abre la ejecución y descarga el artefacto `BongBongScreenFilter-apk`.
5. Descomprímelo e instala `app-debug.apk` en el móvil (permite instalar de fuentes desconocidas).

También se puede abrir esta carpeta en Android Studio y pulsar Run.

## Usarlo
**Con Shizuku (sin root y sin PC):**
1. Instala Shizuku (Google Play o github.com/RikkaApps/Shizuku) e inícialo desde su app con la
   depuración inalámbrica (Android 11 o superior) o con root.
2. Abre BongBong Screen Filter y pulsa "Conectar con Shizuku". Acepta el permiso.
3. Activa "Filtro activo". La app usa Shizuku primero y, si no está disponible, root.
Shizuku se detiene al reiniciar el móvil y hay que volver a iniciarlo; el filtro también se pierde.

**Con root:** abre la app, pulsa "Probar acceso root", acepta el aviso, activa "Filtro activo" y ajusta
los controles. Añade el mosaico "Filtro BongBong" a los ajustes rápidos para activarlo mientras juegas.

**Por ADB desde el PC:** activa la depuración USB, conecta el móvil al PC y ejecuta el comando que muestra la
app (botón "Copiar comando para activar"). Para apagarlo, el comando de "Copiar para apagar".
El filtro dura hasta que reinicies el móvil.

## Limitaciones
- El comando usa la transacción 1015 de SurfaceFlinger. Funciona en muchos móviles, pero algunos
  fabricantes o versiones recientes de Android la bloquean. Si no hace nada, no hay solución desde una app.
- La matriz se aplica sobre la imagen final de la pantalla, así que el resultado puede diferir un poco
  del shader en un juego concreto.
- El código no se ha compilado ni probado en un móvil real. La parte de Shizuku llama a un método
  privado de su API por reflexión, así que conviene probarla en tu móvil.
