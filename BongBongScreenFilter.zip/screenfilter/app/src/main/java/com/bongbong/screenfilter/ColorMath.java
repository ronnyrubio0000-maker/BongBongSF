package com.bongbong.screenfilter;

import java.util.Locale;

/**
 * Convierte el "color grade" de BongBongColory (tinte + saturacion + brillo + contraste)
 * en una matriz de color 4x4 que SurfaceFlinger aplica a toda la pantalla.
 *
 * El color grade del shader es una transformacion afin por pixel:
 *   c1 = c * BRT
 *   c2 = mix(dot(c1, LUM), c1, SAT)
 *   c3 = mix(0.5, c2, CON)
 *   out = tint * c3
 * asi que cabe exacta en una matriz (3x3 mas desplazamiento).
 * Lo que NO se puede hacer con una matriz: ACES, bloom, nitidez (CAS), HDR local y grano.
 */
public final class ColorMath {
    private static final float[] LUM = {0.2125f, 0.7154f, 0.0721f};

    private ColorMath() {}

    private static float frac(float x) {
        return x - (float) Math.floor(x);
    }

    private static float clamp01(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    /** Equivale a: vec3(TINT_BASE) + hue2rgb(hue / 360.0) * TINT_AMOUNT */
    public static float[] tint(float hueDeg, float base, float amount) {
        float h = hueDeg / 360f;
        float[] off = {0f, 2f / 3f, 1f / 3f};
        float[] t = new float[3];
        for (int i = 0; i < 3; i++) {
            float x = frac(h + off[i]) * 6f - 3f;
            float v = clamp01(Math.abs(x) - 1f);
            t[i] = base + v * amount;
        }
        return t;
    }

    /** Matriz 4x4 en orden de columnas (16 floats), como la espera SurfaceFlinger. */
    public static float[] matrix(float hueDeg, float amount, float base, float sat, float brt, float con) {
        float[] tint = tint(hueDeg, base, amount);
        float[] m = new float[16];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                float s = sat * (i == j ? 1f : 0f) + (1f - sat) * LUM[j];
                m[j * 4 + i] = tint[i] * con * brt * s;
            }
            m[12 + i] = tint[i] * 0.5f * (1f - con);
        }
        m[15] = 1f;
        return m;
    }

    private static String f(float v) {
        return String.format(Locale.US, "%.5f", v);
    }

    public static String enableCommand(float[] m) {
        StringBuilder sb = new StringBuilder("service call SurfaceFlinger 1015 i32 1");
        for (float v : m) sb.append(" f ").append(f(v));
        return sb.toString();
    }

    public static String disableCommand() {
        return "service call SurfaceFlinger 1015 i32 0";
    }
}
