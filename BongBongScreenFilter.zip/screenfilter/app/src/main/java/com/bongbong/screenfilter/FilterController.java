package com.bongbong.screenfilter;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Aplica o quita el filtro en SurfaceFlinger (un comando a la vez, en segundo plano). */
final class FilterController {
    interface Callback {
        void done(boolean ok, String message);
    }

    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private FilterController() {}

    /** Lee los ajustes guardados y envia el comando que corresponda. */
    static void apply(Context c, final Callback cb) {
        final String cmd = Settings.load(c).command();
        EXEC.execute(new Runnable() {
            @Override
            public void run() {
                final Shell.Result r = Shell.exec(cmd);
                if (cb != null) {
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            cb.done(r.ok, r.out);
                        }
                    });
                }
            }
        });
    }

    static void test(final Callback cb) {
        EXEC.execute(new Runnable() {
            @Override
            public void run() {
                final Shell.Result r = Shell.exec("id");
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(r.ok && r.out.contains("uid="), r.ok ? "Método: " + r.method + " (" + r.out + ")" : r.out);
                    }
                });
            }
        });
    }
}
