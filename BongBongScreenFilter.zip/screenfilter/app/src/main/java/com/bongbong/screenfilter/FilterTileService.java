package com.bongbong.screenfilter;

import android.graphics.drawable.Icon;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Mosaico de ajustes rapidos para activar o apagar el filtro mientras juegas. */
public class FilterTileService extends TileService {

    @Override
    public void onStartListening() {
        refresh();
    }

    @Override
    public void onClick() {
        boolean on = !Settings.load(this).enabled;
        Settings.saveEnabled(this, on);
        refresh();
        FilterController.apply(this, null);
    }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(Settings.load(this).enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel("Filtro BongBong");
        t.setIcon(Icon.createWithResource(this, android.R.drawable.ic_menu_view));
        t.updateTile();
    }
}
