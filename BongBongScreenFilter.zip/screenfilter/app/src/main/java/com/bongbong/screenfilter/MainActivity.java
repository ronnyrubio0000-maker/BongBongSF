package com.bongbong.screenfilter;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int BG = 0xFF0B0E14;
    private static final int FG = 0xFFE6EBF5;
    private static final int MUTED = 0xFF8995AC;
    private static final int ACCENT = 0xFF5AA9FF;

    private interface FloatSetter {
        void set(float v);
    }

    private Settings s;
    private TextView status;
    private TextView cmdView;
    private TextView methodView;
    private static final int REQ_SHIZUKU = 1001;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable applyTask = new Runnable() {
        @Override
        public void run() {
            applyNow();
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permListener =
            new Shizuku.OnRequestPermissionResultListener() {
                @Override
                public void onRequestPermissionResult(int requestCode, int grantResult) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshMethod();
                        }
                    });
                }
            };
    private final Shizuku.OnBinderReceivedListener binderListener = new Shizuku.OnBinderReceivedListener() {
        @Override
        public void onBinderReceived() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    refreshMethod();
                }
            });
        }
    };
    private final Shizuku.OnBinderDeadListener deadListener = new Shizuku.OnBinderDeadListener() {
        @Override
        public void onBinderDead() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    refreshMethod();
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        s = Settings.load(this);
        Shizuku.addRequestPermissionResultListener(permListener);
        Shizuku.addBinderReceivedListenerSticky(binderListener);
        Shizuku.addBinderDeadListener(deadListener);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshMethod();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener);
        Shizuku.removeBinderReceivedListener(binderListener);
        Shizuku.removeBinderDeadListener(deadListener);
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        tv.setLayoutParams(lp);
        return tv;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(28));
        sv.addView(root);

        root.addView(text("BongBong Screen Filter", 22, FG, true));
        root.addView(text("Aplica el color de BongBongColory (tinte, saturación, brillo y contraste) a toda la pantalla, "
                + "dentro de cualquier juego o app. Funciona con Shizuku, con root o con un comando por ADB.", 14, MUTED, false));

        Switch sw = new Switch(this);
        sw.setText("Filtro activo");
        sw.setTextColor(FG);
        sw.setTextSize(17);
        sw.setChecked(s.enabled);
        LinearLayout.LayoutParams swLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        swLp.topMargin = dp(18);
        sw.setLayoutParams(swLp);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                s.enabled = isChecked;
                s.save(MainActivity.this);
                refreshCommand();
                applyNow();
            }
        });
        root.addView(sw);

        slider(root, "Tono (0 rojo, 120 verde, 240 azul, 300 rosa)", 0f, 360f, 5f, s.hue, "%.0f°", new FloatSetter() {
            public void set(float v) { s.hue = v; }
        });
        slider(root, "Fuerza del tinte", 0f, 0.6f, 0.01f, s.amount, "%.2f", new FloatSetter() {
            public void set(float v) { s.amount = v; }
        });
        slider(root, "Ganancia base del tinte", 0.8f, 1.3f, 0.01f, s.base, "%.2f", new FloatSetter() {
            public void set(float v) { s.base = v; }
        });
        slider(root, "Saturación", 0f, 2f, 0.01f, s.sat, "%.2f", new FloatSetter() {
            public void set(float v) { s.sat = v; }
        });
        slider(root, "Brillo", 0.5f, 1.5f, 0.01f, s.brt, "%.2f", new FloatSetter() {
            public void set(float v) { s.brt = v; }
        });
        slider(root, "Contraste", 0.5f, 1.5f, 0.01f, s.con, "%.2f", new FloatSetter() {
            public void set(float v) { s.con = v; }
        });

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        presets.addView(button("BongBongColory", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s.setBongBong();
                changedAndRebuild();
            }
        }));
        presets.addView(button("Neutro", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s.setNeutral();
                changedAndRebuild();
            }
        }));
        root.addView(presets);

        status = text("Estado: sin aplicar todavía.", 14, ACCENT, false);
        root.addView(status);
        root.addView(text("Cómo se conecta", 17, FG, true));
        methodView = text("", 14, ACCENT, false);
        root.addView(methodView);
        root.addView(text("Con Shizuku no hace falta root ni PC: instala Shizuku, inícialo con la depuración inalámbrica "
                + "(Android 11 o superior) y pulsa Conectar. Si no hay Shizuku, se usa root.", 14, MUTED, false));
        LinearLayout access = new LinearLayout(this);
        access.setOrientation(LinearLayout.HORIZONTAL);
        access.addView(button("Conectar con Shizuku", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectShizuku();
            }
        }));
        access.addView(button("Probar acceso", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                status.setText("Probando…");
                FilterController.test(new FilterController.Callback() {
                    @Override
                    public void done(boolean ok, String message) {
                        status.setText(ok ? message : "Sin acceso. " + message);
                        refreshMethod();
                    }
                });
            }
        }));
        root.addView(access);

        root.addView(text("Alternativa por ADB (PC)", 17, FG, true));
        root.addView(text("Conecta el móvil al PC con la depuración USB activada y ejecuta este comando. "
                + "Se mantiene hasta que reinicies el móvil.", 14, MUTED, false));
        cmdView = text("", 12, FG, false);
        cmdView.setTypeface(Typeface.MONOSPACE);
        cmdView.setTextIsSelectable(true);
        root.addView(cmdView);
        refreshCommand();
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.HORIZONTAL);
        copy.addView(button("Copiar comando para activar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Settings on = Settings.load(MainActivity.this);
                on.enabled = true;
                copyText("adb shell " + on.command());
            }
        }));
        copy.addView(button("Copiar para apagar", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyText("adb shell " + ColorMath.disableCommand());
            }
        }));
        root.addView(copy);

        root.addView(text("Ajustes rápidos", 17, FG, true));
        root.addView(text("Añade el mosaico “Filtro BongBong” a los ajustes rápidos para activarlo o apagarlo mientras juegas "
                + "(funciona con Shizuku o root).", 14, MUTED, false));

        root.addView(text("Qué incluye y qué no", 17, FG, true));
        root.addView(text("Incluye el color grade del shader, calculado igual que en BongBongColory. "
                + "No incluye ACES, bloom, nitidez, HDR local ni grano: una matriz de color no puede hacerlos.", 14, MUTED, false));

        setContentView(sv);
    }

    private void slider(LinearLayout root, final String label, final float min, final float max, final float step,
                        float init, final String format, final FloatSetter setter) {
        final TextView lab = text(String.format(Locale.US, "%s: " + format, label, init), 14, FG, false);
        root.addView(lab);
        SeekBar sb = new SeekBar(this);
        sb.setMax(Math.round((max - min) / step));
        sb.setProgress(Math.round((init - min) / step));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                float v = min + progress * step;
                lab.setText(String.format(Locale.US, "%s: " + format, label, v));
                if (!fromUser) return;
                setter.set(v);
                s.save(MainActivity.this);
                refreshCommand();
                if (s.enabled) {
                    handler.removeCallbacks(applyTask);
                    handler.postDelayed(applyTask, 120);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {}

            @Override
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        root.addView(sb);
    }

    private void changedAndRebuild() {
        s.save(this);
        build();
        if (s.enabled) applyNow();
    }

    private void refreshCommand() {
        if (cmdView == null) return;
        Settings on = Settings.load(this);
        on.enabled = true;
        cmdView.setText("adb shell " + on.command());
    }

    private void refreshMethod() {
        if (methodView == null) return;
        String m;
        if (Shell.shizukuGranted()) m = "Método: Shizuku conectado.";
        else if (Shell.shizukuRunning()) m = "Shizuku está activo, falta el permiso. Pulsa Conectar con Shizuku.";
        else m = "Shizuku no detectado. Se usará root si está disponible.";
        methodView.setText(m);
    }

    private void connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Abre Shizuku y arráncalo primero.", Toast.LENGTH_LONG).show();
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshMethod();
                return;
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                Toast.makeText(this, "Permiso denegado. Actívalo en la app Shizuku, en Aplicaciones autorizadas.", Toast.LENGTH_LONG).show();
                return;
            }
            Shizuku.requestPermission(REQ_SHIZUKU);
        } catch (Throwable t) {
            Toast.makeText(this, "No se pudo hablar con Shizuku: " + t.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void applyNow() {
        FilterController.apply(this, new FilterController.Callback() {
            @Override
            public void done(boolean ok, String message) {
                if (status == null) return;
                status.setText(ok
                        ? (s.enabled ? "Filtro aplicado." : "Filtro apagado.")
                        : "No se pudo aplicar (¿falta Shizuku o root?). " + message);
            }
        });
    }

    private void copyText(String t) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("comando", t));
            Toast.makeText(this, "Comando copiado", Toast.LENGTH_SHORT).show();
        }
    }
}
