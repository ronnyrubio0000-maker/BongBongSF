package com.bongbong.screenfilter;

import android.content.Context;
import android.content.SharedPreferences;

/** Ajustes del filtro, guardados en SharedPreferences. */
final class Settings {
    private static final String PREFS = "filter";

    boolean enabled;
    float hue = 240f;     // COLOR_HUE: 0 rojo, 120 verde, 240 azul, 300 rosa
    float amount = 0.25f; // TINT_AMOUNT
    float base = 1.05f;   // TINT_BASE
    float sat = 1.05f;    // SAT
    float brt = 0.90f;    // BRT
    float con = 1.10f;    // CON

    static Settings load(Context c) {
        SharedPreferences sp = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Settings s = new Settings();
        s.enabled = sp.getBoolean("enabled", false);
        s.hue = sp.getFloat("hue", s.hue);
        s.amount = sp.getFloat("amount", s.amount);
        s.base = sp.getFloat("base", s.base);
        s.sat = sp.getFloat("sat", s.sat);
        s.brt = sp.getFloat("brt", s.brt);
        s.con = sp.getFloat("con", s.con);
        return s;
    }

    void save(Context c) {
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("enabled", enabled)
                .putFloat("hue", hue)
                .putFloat("amount", amount)
                .putFloat("base", base)
                .putFloat("sat", sat)
                .putFloat("brt", brt)
                .putFloat("con", con)
                .apply();
    }

    static void saveEnabled(Context c, boolean on) {
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("enabled", on).apply();
    }

    void setBongBong() {
        hue = 240f; amount = 0.25f; base = 1.05f; sat = 1.05f; brt = 0.90f; con = 1.10f;
    }

    void setNeutral() {
        hue = 240f; amount = 0f; base = 1f; sat = 1f; brt = 1f; con = 1f;
    }

    float[] matrix() {
        return ColorMath.matrix(hue, amount, base, sat, brt, con);
    }

    String command() {
        return enabled ? ColorMath.enableCommand(matrix()) : ColorMath.disableCommand();
    }
}
