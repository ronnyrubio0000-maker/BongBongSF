package com.bongbong.screenfilter;

import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Ejecuta comandos con privilegios: primero Shizuku (si esta autorizado) y si no, root con "su". */
final class Shell {
    static final class Result {
        final boolean ok;
        final String out;
        final String method;

        Result(boolean ok, String out, String method) {
            this.ok = ok;
            this.out = out;
            this.method = method;
        }
    }

    private static boolean waited;

    private Shell() {}

    static boolean shizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean shizukuGranted() {
        try {
            return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Tras arrancar el proceso, Shizuku tarda un instante en entregar su binder. Espera como maximo 1,5 s, una sola vez. */
    private static synchronized void waitForBinderOnce() {
        if (waited) return;
        waited = true;
        for (int i = 0; i < 15 && !shizukuRunning(); i++) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    static Result exec(String cmd) {
        waitForBinderOnce();
        if (shizukuGranted()) return viaShizuku(cmd);
        Result r = su(cmd);
        if (!r.ok && shizukuRunning()) {
            return new Result(false, r.out + "\nShizuku está activo pero falta el permiso: pulsa \"Conectar con Shizuku\".", r.method);
        }
        return r;
    }

    private static Result collect(Process p, String method) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line).append('\n');
        int code = p.waitFor();
        return new Result(code == 0, sb.toString().trim(), method);
    }

    private static Result viaShizuku(String cmd) {
        Process p = null;
        try {
            // newProcess es privado en la API 13 de Shizuku; se llama por reflexion.
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Object[] args = new Object[]{new String[]{"sh", "-c", cmd + " 2>&1"}, null, null};
            p = (Process) m.invoke(null, args);
            return collect(p, "Shizuku");
        } catch (Throwable t) {
            return new Result(false, "Error con Shizuku: " + t, "Shizuku");
        } finally {
            if (p != null) p.destroy();
        }
    }

    static Result su(String cmd) {
        Process p = null;
        try {
            p = new ProcessBuilder("su").redirectErrorStream(true).start();
            OutputStream os = p.getOutputStream();
            os.write((cmd + "\nexit\n").getBytes("UTF-8"));
            os.flush();
            os.close();
            return collect(p, "root");
        } catch (Exception e) {
            return new Result(false, "No hay root: " + e.getMessage(), "root");
        } finally {
            if (p != null) p.destroy();
        }
    }
}
